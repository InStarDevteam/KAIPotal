# 국방지능형플랫폼포털 제안서 자료 패키지

> K-Defense Intelligence Platform PoC 결과를 바탕으로 한 제안서 작성·발표용 자료 패키지입니다.

## 패키지 구성

| 경로 | 설명 |
|------|------|
| `screenshots/` | 최종 화면 캡처 18개 (`01-portal-dashboard.png` ~ `09-backstage-signin.png`) |
| `국방지능형플랫폼포털_제안서.md` | 최종 제안서 Markdown 본문 |
| `국방지능형플랫폼포털_제안발표자료.pptx` | 최종 발표자료(23장) |
| `국방지능형플랫폼포털_견적산정표.xlsx` | 최종 견적 산정표(5시트) |
| `kt-ai-portal-proposal-materials.zip` | 스크린샷 + 핵심 문서 압축 파일 |
| `README.md` | 본 파일 |

## 캡처 목록

| No | 파일명 | 화면 | 제안서 삽입 위치 |
|----|--------|------|------------------|
| 01 | `01-portal-dashboard.png` | Portal Dashboard | 1장 플랫폼 개요 |
| 02 | `02-integrated-search.png` | 통합검색 | 3장 통합검색/카탈로그 |
| 03 | `03-project-workspace.png` | 프로젝트/워크스페이스 | 4장 프로젝트/워크스페이스 |
| 04 | `04-export-approval.png` | 반입·반출 승인 | 5장 반입/반출 관리 |
| 05 | `05-credit-manager.png` | 크레딧 관리 | 6장 크레딧/사용량 |
| 06 | `06-krmf-evidence.png` | K-RMF 증빙관리 | 7장 K-RMF/감사 |
| 07 | `07-admin-console-user-management.png` | 관리자 콘솔 – 사용자 관리 | 8장 관리자 기능 – 사용자 |
| 08 | `08-admin-console-rbac-menu.png` | 관리자 콘솔 – 권한/RBAC | 8장 관리자 기능 – 권한 |
| 09 | `09-admin-console-policy-audit.png` | 관리자 콘솔 – 정책/감사 | 8장 관리자 기능 – 정책/감사 |
| 10 | `10-service-catalog.png` | 서비스/도구 카탈로그 | 3장 서비스/도구 카탈로그 |
| 11 | `11-proposal-board.png` | 제안 게시판 | 9장 제안 게시판 |
| 12 | `12-my-page.png` | 마이페이지 | 10장 마이페이지 |
| 13 | `13-environment-settings.png` | 환경설정 | 10장 환경설정 |
| 14 | `14-tenant-management.png` | 육해공군 관리 | 11장 군별 관리 |
| 15 | `15-openmetadata-catalog.png` | OpenMetadata Catalog | 3장 데이터 거버넌스 |
| 16 | `16-opensearch-catalog-index.png` | OpenSearch Dashboards | 3장 검색 인프라 |
| 17 | `09-keycloak-login.png` | Keycloak Login | 2장 보안/인증 |
| 18 | `09-backstage-signin.png` | Backstage Sign-In | 2장 로그인 |

## 핵심 참고 문서

프로젝트 루트 `docs/` 디렉터리에서 확인할 수 있습니다.

### 21단계 산출물

- `docs/FINAL_REQUIREMENT_TRACEABILITY_MATRIX.md` — 견적용 기능목록 1~155 대응표
- `docs/SCREEN_TO_RFP_MAPPING.md` — 화멸별 RFP 매핑표
- `docs/REQUIREMENT_SCREEN_COVERAGE.md` — 화면 기준 충족도 평가
- `docs/PROPOSAL_SCREENSHOT_CATALOG.md` — 캡처 상세 목록 및 촬영 상태
- `docs/SCREENSHOT_CAPTIONS.md` — 제안서 삽입용 캡션
- `docs/PROPOSAL_SUMMARY_TEXT.md` — 제안서 작성용 요약 문구
- `docs/ESTIMATION_TABLE.md` — 기능별 M/M 및 견적 산정 기준
- `docs/DEMO_SCRIPT.md` — 최종 데모 시나리오
- `docs/FINAL_DELIVERABLES.md` — 최종 산출물 목록

### 22단계 산출물

- `docs/PROPOSAL_OUTLINE.md` — 제안서 목차 초안
- `docs/PROPOSAL_DRAFT.md` — 제안서 본문 초안
- `docs/PROPOSAL_SLIDE_DRAFT.md` — 발표자료 초안
- `docs/ESTIMATE_DRAFT.md` — 견적서 초안
- `docs/RFP_MAPPING_JUSTIFICATION.md` — RFP 매핑 근거 설명
- `docs/IMPLEMENTATION_ROADMAP.md` — 구현 로드맵
- `docs/RISK_RESPONSE_PLAN.md` — 리스크 및 대응방안

## 23단계 최종 산출물

- `국방지능형플랫폼포털_제안서.md` — 제안서 최종본
- `국방지능형플랫폼포털_제안발표자료.pptx` — 발표자료 23장
- `국방지능형플랫폼포털_견적산정표.xlsx` — 기능별/역할별/공통 M/M 산정

## 23.5단계 역검증 문서

- `docs/FINAL_REQUIREMENT_VALIDATION_REPORT.md` — 요구사항 역검증 보고서(SFR-001~SFR-021 매핑 포함)

## 24단계 데모 배포 준비 문서

- `docs/FIREBASE_DEMO_DEPLOYMENT.md` — Firebase Hosting + Cloud Run 데모 배포 가이드
- `docs/FIREBASE_DEMO_CHECKLIST.md` — 데모 배포 체크리스트
- `docs/SCREEN_USER_GUIDE.md` — 화면 사용 설명서(데모 접속 안내)

> 실제 GCP/Firebase 프로젝트 생성 및 가비아 DNS 연결은 미진행 상태입니다.

## 촬영 정보

- **촬영 일자**: 2026-07-04
- **촬영 환경**: Backstage dev server `http://localhost:3000`, Chromium 1920×1080, Guest 로그인
- **명칭 기준**: `국방지능형플랫폼포털` / `K-Defense Intelligence Platform`
- **메뉴 기준**: 20.5단계 한글 메뉴 (`통합 대시보드`, `통합검색`, `프로젝트/워크스페이스`, `반입·반출 승인`, `크레딧 관리`, `K-RMF 증빙관리`, `관리자 콘솔`, `서비스/도구 카탈로그`, `제안 게시판`, `마이페이지`, `환경설정`, `육해공군 관리`)

## 사용 안내

1. `screenshots/`의 PNG 파일을 PPT/Word에 직접 삽입하세요.
2. `docs/SCREENSHOT_CAPTIONS.md`의 문구를 그림 설명으로 활용하세요.
3. `docs/PROPOSAL_DRAFT.md`의 본문 문구를 제안서 원고로 활용하세요.
4. `docs/PROPOSAL_SLIDE_DRAFT.md`를 바탕으로 PPT를 작성하세요.
5. `docs/ESTIMATE_DRAFT.md`와 `docs/ESTIMATION_TABLE.md`의 M/M를 실제 견적 시 조정하세요.
6. `docs/RFP_MAPPING_JUSTIFICATION.md`를 활용해 RFP 대응 근거를 설명하세요.
7. 제안서 발표 순서는 `docs/DEMO_SCRIPT.md`와 `docs/PROPOSAL_SLIDE_DRAFT.md`를 참고하세요.
